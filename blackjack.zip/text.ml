let welcome_string =
  "\n\n\
   Welcome to the Blackjack engine.\n\
   You are starting with 100 chips."

let start_round_string =
  "\n\n\
   The round is now starting. \n\
   The deck has been created and shuffled.\n\
  \ \n"

let dealer_card1_string = "\nThe dealer's first card is: \n"

let new_round_string = "\nA new round is starting, get ready!\n"

let h_or_s = "Do you want to hit or stay?\n"

let invalid_input = "Invalid action. Please try again."
